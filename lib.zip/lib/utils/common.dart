class Common {
  static String token = 'accessToken';

}