import 'package:flutter/material.dart';
import 'package:product_listing_app/utils/color_constants.dart';


class CommonButton extends StatelessWidget {
  final VoidCallback onPressed;
  final String text;
  final Color backgroundColor;
  final GlobalKey<FormState>? formKey;

  const CommonButton({
    required this.onPressed,
    required this.text,
    this.backgroundColor = ColorConstant.appBlue,
    this.formKey,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      height: 48,
      child: ElevatedButton(
        onPressed: () {
          if (formKey == null || formKey!.currentState!.validate()) {
            onPressed();
          }
        },
        style: ElevatedButton.styleFrom(
          backgroundColor: backgroundColor,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10),
          ),
        ),
        child: Text(
          text,
          style: const TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.w600,
            color: Colors.white,
          ),
        ),
      ),
    );
  }
}
