class ApiUrls {
  /// base URL
  static const base = 'https://admin.kushinirestaurant.com/api/';
  static const verifyUser = '${base}verify/';
  static const loginRegister = '${base}login-register/';
}
