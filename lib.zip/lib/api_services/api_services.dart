import 'dart:convert';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:product_listing_app/api_services/urls.dart';
import '../view/login_screen/model/login_model.dart';

class ApiServices {
  static final Dio _dio = Dio();

  /// Verify User API
  static Future verifyUser({required Map<String, dynamic> body}) async {
    print('ebhbehbjh');
    var response = await _dio.post(
      ApiUrls.verifyUser,
      data: jsonEncode(body),
      options: Options(
        headers: {
          'Content-Type': 'application/json',
        },
      ),
    );
    print('hhhhhhh');
    print(response.data);
    if (response.statusCode == 200) {
      return VerifyUserModel.fromJson(response.data);
    } else {
      Get.snackbar(
        "Alert",
        "Something went wrong",
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: Colors.red,
        colorText: Colors.white,
      );

      throw Exception(response.data);
    }
  }

  static Future loginOrRegister({required Map<String, dynamic> body}) async {
    var response = await _dio.post(
      ApiUrls.loginRegister,
      data: jsonEncode(body),
      options: Options(
        headers: {
          'Content-Type': 'application/json',
        },
      ),
    );

    if (response.statusCode == 200) {
      return verifyUserModelFromJson(response.data);
    } else {
      Get.snackbar(
        "Alert",
        "Something went wrong",
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: Colors.red,
        colorText: Colors.white,
      );

      throw Exception(response.data);
    }
  }
}
