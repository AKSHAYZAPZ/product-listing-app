import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:product_listing_app/view/home_screen/view/home_screen.dart';
import 'package:product_listing_app/view/profile/view/profile_screen.dart';
import 'package:product_listing_app/view/wishlist/view/wishlist_screen.dart';


class BottomNavigationController extends GetxController {
  Rx<int> selectedIndex = 0.obs;

  final List<Widget> screens = [
    HomeScreen(),
    WishlistScreen(),
    ProfileScreen()
  ];

  final List<Map<String, dynamic>> navItems = [
    {"icon": Icons.home, "label": "Home"},
    {"icon": Icons.favorite, "label": "Wishlist"},
    {"icon": Icons.person, "label": "Profile"},
  ];

  void changeIndex(int index) {
    selectedIndex.value = index;
  }
}
