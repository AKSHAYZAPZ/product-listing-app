import 'dart:async';

import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';

class HomeController extends GetxController{

  TextEditingController searchController = TextEditingController();
  final PageController pageController = PageController();
  final RxInt currentPage = 0.obs;
  Timer? autoSlideTimer;
  final List<Map<String, dynamic>> banners = [
    {
      "image":
      "https://img.freepik.com/free-vector/modern-abstract-gradient-background-with-elegant-elements-vector-illustration_361591-3815.jpg",
    },
    {
      "image":
      "https://plus.unsplash.com/premium_photo-1701590725747-ac131d4dcffd?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MXx8d2Vic2l0ZSUyMGJhbm5lcnxlbnwwfHwwfHx8MA%3D%3D",
    },
    {
      "image":
      "https://cdn.pixabay.com/photo/2015/10/29/14/38/web-1012467_1280.jpg",
    },
  ];

  void onPageChanged(int index) {
    currentPage.value = index;
  }

  @override
  void onInit() {
    super.onInit();
    startAutoSlide();
  }

  void startAutoSlide() {
    autoSlideTimer = Timer.periodic(const Duration(seconds: 3), (timer) {
      if (currentPage.value < banners.length - 1) {
        currentPage.value++;
        pageController.animateToPage(
          currentPage.value,
          duration: const Duration(milliseconds: 500),
          curve: Curves.easeInOut,
        );
      } else {
        currentPage.value = 0;
        pageController.jumpToPage(0);
      }
    });
  }

  @override
  void onClose() {
    autoSlideTimer?.cancel();
    pageController.dispose();
    super.onClose();
  }

}