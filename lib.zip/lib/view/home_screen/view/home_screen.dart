import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:product_listing_app/utils/color_constants.dart';
import 'package:product_listing_app/utils/widgets/custom_text.dart';
import 'package:product_listing_app/utils/widgets/product_grid.dart';
import 'package:product_listing_app/view/home_screen/controller/home_controller.dart';


import '../../../network_controller/nework_controller.dart';
import '../../../utils/widgets/search_textfield.dart';

class HomeScreen extends StatelessWidget {
  HomeScreen({super.key});

  NetworkController networkController = Get.put(NetworkController());

  @override
  Widget build(BuildContext context) {
    return Obx(() {
      if (networkController.isConnected.value) {
        HomeController homeController = Get.put(HomeController());
        return Scaffold(
          backgroundColor: ColorConstant.white,
          appBar: AppBar(
            scrolledUnderElevation: 0,
            toolbarHeight: 100,
            backgroundColor: ColorConstant.white,
            automaticallyImplyLeading: false,
            title: AppShadowTextFormField(
              controller: homeController.searchController,
              hint: "Search",
              radius: 20,
              suffixIcon: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 15),
                child: SizedBox(
                  width: MediaQuery.of(context).size.width * 0.2,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      SizedBox(
                        height: MediaQuery.of(context).size.height * 0.025,
                        child: const VerticalDivider(
                          width: 5,
                          color: Colors.black,
                        ),
                      ),
                      SizedBox(
                        width: MediaQuery.of(context).size.width * 0.02,
                      ),
                      const Icon(Icons.search),
                    ],
                  ),
                ),
              ),
            ),
          ),
          body: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 15),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(
                  height: MediaQuery.of(context).size.height * 0.2,
                  width: Get.width,
                  child: PageView.builder(
                    reverse: false,
                    controller: homeController.pageController,
                    onPageChanged: homeController.onPageChanged,
                    itemCount: homeController.banners.length,
                    itemBuilder: (context, index) {
                      final banner = homeController.banners[index];
                      return Container(
                        margin: const EdgeInsets.symmetric(horizontal: 8),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(16),
                        ),
                        child: ClipRRect(
                          borderRadius:
                              const BorderRadius.all(Radius.circular(20)),
                          child: Image.network(
                            banner['image'],
                            fit: BoxFit.cover,
                          ),
                        ),
                      );
                    },
                  ),
                ),
                SizedBox(height: MediaQuery.of(context).size.height * 0.015),
                Obx(() {
                  return Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children:
                        List.generate(homeController.banners.length, (index) {
                      return AnimatedContainer(
                        duration: const Duration(milliseconds: 300),
                        margin: const EdgeInsets.symmetric(horizontal: 4),
                        height: 8,
                        width:
                            homeController.currentPage.value == index ? 24 : 8,
                        decoration: BoxDecoration(
                          color: homeController.currentPage.value == index
                              ? ColorConstant.black
                              : ColorConstant.shadowColor.withOpacity(0.5),
                          borderRadius: BorderRadius.circular(12),
                        ),
                      );
                    }),
                  );
                }),
                const Padding(
                    padding: EdgeInsets.symmetric(horizontal: 8),
                    child: HeeboFontText(
                      text: 'Popular Product',
                      fontSize: 15,
                      color: ColorConstant.textBlue,
                      fontWeight: FontWeight.w500,
                    )),
                const SizedBox(height: 10),
                Expanded(
                  child: GridView.builder(
                    physics: const BouncingScrollPhysics(),
                    gridDelegate:
                        const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 2,
                      crossAxisSpacing: 10,
                      mainAxisSpacing: 10,
                      childAspectRatio: 0.7,
                    ),
                    itemCount: 10,
                    itemBuilder: (context, index) {
                      return const ProductGrid(
                          productImage:
                              'https://www.cureka.com/wp-content/uploads/2022/08/Layer_78-16.jpg',
                          productName: 'Horlicks',
                          price: '20',
                          cutPrice: '200',
                          isWishList: true,
                          rating: 5);
                    },
                  ),
                ),
              ],
            ),
          ),
        );
      } else {
        return networkController.noDataImage(context);
      }
    });
  }
}
