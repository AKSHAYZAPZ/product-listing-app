import 'dart:convert';

LoginOrRegisterModel loginOrRegisterModelFromJson(String str) =>
    LoginOrRegisterModel.fromJson(json.decode(str));

String loginOrRegisterModelToJson(LoginOrRegisterModel data) =>
    json.encode(data.toJson());

class LoginOrRegisterModel {
  final Token? token;
  final String? userId;
  final String? message;

  LoginOrRegisterModel({
    this.token,
    this.userId,
    this.message,
  });

  factory LoginOrRegisterModel.fromJson(Map<String, dynamic> json) =>
      LoginOrRegisterModel(
        token: json["token"] == null ? null : Token.fromJson(json["token"]),
        userId: json["user_id"],
        message: json["message"],
      );

  Map<String, dynamic> toJson() => {
    "token": token?.toJson(),
    "user_id": userId,
    "message": message,
  };
}

class Token {
  final String? access;

  Token({
    this.access,
  });

  factory Token.fromJson(Map<String, dynamic> json) => Token(
    access: json["access"],
  );

  Map<String, dynamic> toJson() => {
    "access": access,
  };
}