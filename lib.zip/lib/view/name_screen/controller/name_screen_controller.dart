import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';

class NameScreenController extends GetxController{

  TextEditingController nameTextController = TextEditingController();

}